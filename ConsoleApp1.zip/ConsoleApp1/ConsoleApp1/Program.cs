﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace

Calculator
{
    class

Program
    {
        static

void

Main(string[] args)
        {
            // Välkomnande meddelande


            // En lista för att spara historik för räkningar


            // Användaren matar in tal och matematiska operation


            // OBS! Användaren måsta mata in ett tal för att kunna ta sig vidare i programmet!


            // Ifall användaren skulle dela med 0 visa Ogiltig inmatning!


            // Lägga resultat till listan


            // Visa resultat


            // Fråga användaren om den vill visa tidigare resultat.


            // Visa tidigare resultat


            // Fråga användaren om den vill avsluta eller fortsätta

            // Input / output
            // Lista med historik
            // Kontrollstrukturer
            // Välja lämpligt designmönster
            // Källkodshantering med GIT

            // Ändra färgen på texten i consolen
            Console.ForegroundColor = ConsoleColor.Blue;
            // Välkomnande meddelande
            Console.WriteLine("Välkommen till miniräknaren!");

            // En lista för att spara historik för räkningar
            List<double> historik = new List<double>();

            while (true)
            {
                // Ange ett tal
                Console.WriteLine("Ange ett tal:");
                double firstNumber = Convert.ToDouble(Console.ReadLine());

                // Välj en operation
                Console.Write("Välj en operation ( + , - , * , / ):");
                char operation = Convert.ToChar(Console.ReadLine());

                // Ange nästa tal
                Console.Write("Ange nästa tal:");
                double secondNumber = Convert.ToDouble(Console.ReadLine());

                // Gör beräkningen
                double result = 0;
                switch (operation)
                {
                    case

'+':
                        result = firstNumber + secondNumber;
                        break;
                    case

'-':
                        result = firstNumber - secondNumber;
                        break;
                    case

'*':
                        result = firstNumber * secondNumber;
                        break;
                    case

'/':
                        if (secondNumber != 0)
                        {
                            result = firstNumber / secondNumber;
                        }
                        else
                        {
                            Console.WriteLine("Det går inte att dividera med noll!");
                            continue;
                        }
                        break;
                    default:
                        Console.WriteLine("Ogiltig operation! Försök igen.");
                        continue;
                }

                // Lägg till resultatet till listan
                historik.Add(result);

                // Visa resultatet
                Console.WriteLine("Resultatet är: {0}", result);

                // Vill du fortsätta?
                Console.WriteLine("Vill du fortsätta? (J/N)");
                if (Console.ReadLine()[0] != 'J')
                {
                    break;
                }
            }

            // Visa tidigare resultat
            if (historik.Count > 0)
            {
                Console.WriteLine("Tidigare resultat:");
                foreach (double i in historik)
                {
                    Console.WriteLine("{0}", i);
                }
            }

            // Vill du avsluta?
            Console.WriteLine("Vill du avsluta? (J/N)");
        }
    }
}
